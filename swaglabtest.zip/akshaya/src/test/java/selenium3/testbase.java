package selenium3;

import java.io.File;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;



public class testbase { 
	public static WebDriver driver;
	public static Actions a;
	public static WebDriverWait wait; 
	public static TakesScreenshot tss;
	
	
	public static void browsersetup()
	
	{
		ChromeOptions c = new ChromeOptions();
		c.addArguments("---guest");
		 driver = new ChromeDriver(c);
		  a = new Actions(driver);
		wait =new WebDriverWait(driver, Duration.ofSeconds(20));
	    tss = (TakesScreenshot) driver;


		
	}
	
	public static void max()
	{
		driver.manage().window().maximize();
	}
	public static void geturl(String url)
	{
		driver.get(url);
	}
	public static void validcre()
	{
		WebElement un = driver.findElement(By.xpath("//input[contains(@placeholder,'Username')]"));
		WebElement pass = driver.findElement(By.xpath("//input[contains(@type,'password')]"));
		
		un.sendKeys("standard_user");
		pass.sendKeys("secret_sauce");
		
		
	}	
	public static void cre(String a , String b )
	{
		WebElement un = driver.findElement(By.xpath("//input[contains(@placeholder,'Username')]"));
		WebElement pass = driver.findElement(By.xpath("//input[contains(@type,'password')]"));
		
		un.sendKeys(a);
		pass.sendKeys(b);
		
		
	}	
	public static void click()
	{
		WebElement log = driver.findElement(By.xpath("//input[contains(@id,'login-button')]"));
		a.click(log).build().perform();
	
	}

	public static void teardown()
	{
		driver.quit();
	}
    public static void takess(String name)
	
	{	
	

	try {
	    TakesScreenshot tss = (TakesScreenshot) driver;
	    File cap = tss.getScreenshotAs(OutputType.FILE);
	    File src = new File("C:\\Users\\91882\\eclipse-workspace\\akshaya\\target\\"+name+".png");
	    FileHandler.copy(cap, src);
	    
	} catch (Exception e) {
	    System.out.println(e);}
	}
public static void explwait()
{
	WebElement dd = driver.findElement(By.xpath("//select[contains(@data-test,'product-sort-container')]"));
	wait.until(ExpectedConditions.visibilityOf(dd));
	
	System.out.println("succefully logged-in");
}

public static void menu ()

{
	WebElement menu = driver.findElement(By.xpath("//button[contains(@id,'react-burger-menu-btn')] "));
	wait.until(ExpectedConditions.elementToBeClickable(menu));
	wait.until(ExpectedConditions.visibilityOf(menu));
	a.click(menu).build().perform();
	
	WebElement menud = driver.findElement(By.xpath("//div[contains(@style,'height')]"));
	wait.until(ExpectedConditions.visibilityOf(menud));
	
	System.out.println("menu button successfully working");
	
}
public static void clickAbout()
{
    WebElement about = driver.findElement(By.xpath("//a[contains(@data-test,'about-sidebar-link')]"));
    wait.until(ExpectedConditions.elementToBeClickable(about));
    wait.until(ExpectedConditions.visibilityOf(about));
    about.click();
    System.out.println("About button in the menu bar is working successfully");

}
public static void logoutusinglogoutbotton()
{
	WebElement lo = driver.findElement(By.xpath("//a[contains(@data-test,'logout-sidebar-link')]"));
	wait.until(ExpectedConditions.elementToBeClickable(lo));
	wait.until(ExpectedConditions.visibilityOf(lo));
	lo.click();
	System.out.println("successfully logged out");
	
}
   public static void clickimage()
   {
	   WebElement ci = driver.findElement(By.xpath("//img[contains(@data-test,'inventory-item-sauce-labs-backpack-img')]"));
	   wait.until(ExpectedConditions.elementToBeClickable(ci));
	   wait.until(ExpectedConditions.visibilityOf(ci));
	   ci.click();
	   System.out.println("successfully image is clicked");
   }
   public static void clickproductname()
   {
	   WebElement cpn = driver.findElement(By.xpath("//div[contains(@data-test,'inventory-item-name')]"));
	   wait.until(ExpectedConditions.elementToBeClickable(cpn));
	   wait.until(ExpectedConditions.visibilityOf(cpn));
	   cpn.click();
	   System.out.println("product name is clicked successfully");
	     
   }
   public static void backtohomefromproduct()
   {
	   WebElement bp = driver.findElement(By.xpath("//button[contains(@data-test,'back-to-products')]"));
	   wait.until(ExpectedConditions.elementToBeClickable(bp));
	   wait.until(ExpectedConditions.visibilityOf(bp));
	   bp.click();
	   System.out.println("back from product successfully");
   }
   
   public static void backtohome()
   {
	driver.navigate().back();
    }
    public static void addtocartforproduct()
    {
	WebElement atc = driver.findElement(By.xpath("//button[contains(@data-test,'add-to-cart-sauce-labs-bike-light')]"));
	wait.until(ExpectedConditions.elementToBeClickable(atc));
	wait.until(ExpectedConditions.visibilityOf(atc));
	atc.click();
	System.out.println("Add to cart button is working successfully");
    }
    public static void removeaddtocartforproduct()
    {
    	WebElement rem= driver.findElement(By.xpath("//button[contains(@data-test,'remove-sauce-labs-bike-light')]"));
    	wait.until(ExpectedConditions.elementToBeClickable(rem));
    	wait.until(ExpectedConditions.visibilityOf(rem));
    	rem.click();
    	System.out.println("product removed button is working successfully");
    	
    }
    public static void addtocarticon()
    {
    	WebElement atc =driver.findElement(By.xpath("//a[contains(@data-test,'shopping-cart-link')]"));
    	wait.until(ExpectedConditions.elementToBeClickable(atc));
    	wait.until(ExpectedConditions.visibilityOf(atc));
    	atc.click();
    	System.out.println("add to cart icon is working successfully");
    }
    public static void filter (String value)
	{
	WebElement filter =	driver.findElement(By.xpath("//select[contains(@data-test,'product-sort-container')]"));
	wait.until(ExpectedConditions.visibilityOf(filter));
	Select s = new Select(filter);
	List<WebElement> li =s.getOptions();
	for (WebElement aa : li)
	{ 
	System.out.println(aa.getText());
	
	if(aa.getText().equals(value))
	{
		System.out.println(aa);
		aa.click();
		break;

	}
	}
	}
    public static void wind ()
	{
		WebElement face = driver.findElement(By.xpath("//a[text()='Facebook']"));
		wait.until(ExpectedConditions.elementToBeClickable(face));
		wait.until(ExpectedConditions.visibilityOf(face));
		WebElement li = driver.findElement(By.xpath("//a[text()='LinkedIn']"));
		wait.until(ExpectedConditions.elementToBeClickable(li));
		wait.until(ExpectedConditions.visibilityOf(li));
		WebElement tw = driver.findElement(By.xpath("//a[text()='Twitter']"));
		wait.until(ExpectedConditions.elementToBeClickable(tw));
		wait.until(ExpectedConditions.visibilityOf(tw));
		face.click();
		li.click();
		a.click(tw).build().perform();
		//driver.quit();
		String parenttab = driver.getWindowHandle();
		Set<String> tabs = driver.getWindowHandles();
		System.out.println(parenttab);
		for (String aa : tabs)
		{
			System.out.println(aa);
			driver.switchTo().window(aa);
			String title = driver.getTitle();
			System.out.println(title);
		}
	}
    public static void facebook()
    {
    	WebElement face = driver.findElement(By.xpath("//a[text()='Facebook']"));
		wait.until(ExpectedConditions.elementToBeClickable(face));
		wait.until(ExpectedConditions.visibilityOf(face));
		face.click();
		System.out.println("facebook is working successfully ");
    }

    public static void twitter()
    {
    	WebElement tw = driver.findElement(By.xpath("//a[text()='Twitter']"));
		wait.until(ExpectedConditions.elementToBeClickable(tw));
		wait.until(ExpectedConditions.visibilityOf(tw));
		a.click(tw).build().perform();
		System.out.println("twitter is working successfully ");
    }
    public static void linkedin()
    {
    	WebElement li = driver.findElement(By.xpath("//a[text()='LinkedIn']"));
		wait.until(ExpectedConditions.elementToBeClickable(li));
		wait.until(ExpectedConditions.visibilityOf(li));
		li.click();
		System.out.println("linkedin is working successfully ");
    }
    
	public static void main(String[] args) {
		
	}

}
