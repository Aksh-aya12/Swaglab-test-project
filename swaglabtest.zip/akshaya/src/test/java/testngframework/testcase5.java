package testngframework;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import selenium3.testbase;

public class testcase5 {
	@BeforeTest
	public void bt()
	{
		testbase.browsersetup();
	}
	@BeforeMethod
	public void bm ()
	{
		testbase.max();
		testbase.geturl("https://www.saucedemo.com/");
		testbase.validcre();
		testbase.click();
	}
	@Test
	public void menulogout()
	{
		testbase.menu();
		testbase.logoutusinglogoutbotton();
		
	}
	@AfterMethod
	public void am()
	{
		testbase.takess("loggedout page");
		
	}
	@AfterTest
	public void at ()
	{
		testbase.teardown();
	}
	
	}
