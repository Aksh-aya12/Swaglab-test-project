package testngframework;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import selenium3.testbase;

public class testngtestcase2 {
	@BeforeTest
	public void bt ()
	{
	  testbase.browsersetup();
	}
	
	@BeforeMethod
	public void bm ()
	{
		testbase.max();
		testbase.geturl("https://www.saucedemo.com/");
		
	}
	@Test
	public void invalidcred ()
	{
		// In string we can give valid Username and password 
		// invalid username and password
		// valid username invaild password
		// invaild username vaild password
		
		testbase.cre("standard_user ", "sec ");
		testbase.click();
		
	}
	@AfterMethod 
	public void am()
	{
		testbase.takess("Error message");
		
	}
	@AfterTest
	public void at ()
	{
		testbase.teardown();
	}
	
}
