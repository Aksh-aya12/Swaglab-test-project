package testngframework;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import selenium3.testbase;

public class testcase10filter {
	@BeforeTest
	public void bt ()
	{
		testbase.browsersetup();
	}
	@BeforeMethod
	public void bm ()
	{
		testbase.max();
		testbase.geturl("https://www.saucedemo.com/");
		testbase.validcre();
		testbase.click();
	}
	@Test
	public void sort()
	{
		testbase.filter("Name (A to Z)");
		testbase.filter("Name (Z to A)");
		testbase.filter("Price (low to high)");
		testbase.filter("Price (high to low)");
	}
	@AfterMethod
	public void am()
	{
		
		testbase.takess("filter");
		
	}
	@AfterTest
	public void at()
	{
		testbase.teardown();
	}

}
