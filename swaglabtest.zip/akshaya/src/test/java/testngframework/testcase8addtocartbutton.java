package testngframework;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import selenium3.testbase;

public class testcase8addtocartbutton {
	@BeforeTest
	public void bt ()
	{
		testbase.browsersetup();
	}
	@BeforeMethod
	public void bm ()
	{
		testbase.max();
		testbase.geturl("https://www.saucedemo.com/");
		testbase.validcre();
		testbase.click();
	}
	@Test
	public void addtocartforproduct()
	{
		testbase.addtocartforproduct();
	}
	@AfterMethod
	public void am()
	{
		testbase.removeaddtocartforproduct();
		
	}
	@AfterTest
	public void at()
	{
		testbase.teardown();
	}
	
}
